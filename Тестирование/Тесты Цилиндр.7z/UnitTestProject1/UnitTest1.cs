﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using Cylinder;

namespace UnitTestProject1
{
    [TestClass]
    public class CylinderChekerTest
    {
        [TestMethod]
        public void CalcCylinderVolume_0and0_NullReturned()
        {
            
            double r = 0;
            double h = 0;
            double? expected = null;

            
            double? actual = CylinderCheker.CalculateVolume(r, h);

            
            Assert.AreEqual(expected, actual);
        }
        [TestMethod]
        public void CalcCylinderVolume_0Point1and0Point1_0Point0031Returned()
        {
            
            double r = 0.1;
            double h = 0.1;
            double expected = 0.0031;

            
            double? actual = CylinderCheker.CalculateVolume(r, h);

            
            Assert.AreEqual(expected, Math.Round(actual.Value, 4));
        }

        [TestMethod]
        public void CalcCylinderVolume_Minus3andMinus3_NullReturned()
        {
            
            double r = -3;
            double h = -3;
            double? expected = null;

            
            double? actual = CylinderCheker.CalculateVolume(r, h);

            
            Assert.AreEqual(expected, actual);
        }
        [TestMethod]
        public void CalcCylinderVolume_2and0_NullReturned()
        {
            
            double r = 2;
            double h = 0;
            double? expected = null;

            
            double? actual = CylinderCheker.CalculateVolume(r, h);

            
            Assert.AreEqual(expected, actual);
        }
        [TestMethod]
        public void CalcCylinderVolume_0and2_NullReturned()
        {
            
            double r = 0;
            double h = 2;
            double? expected = null;

            
            double? actual = CylinderCheker.CalculateVolume(r, h);

            
            Assert.AreEqual(expected, actual);
        }
        [TestMethod]
        public void CalcCylinderVolume_2and2_25Point1327Returned()
        {
            
            double r = 2;
            double h = 2;
            double expected = 25.1327;

            
            double? actual = CylinderCheker.CalculateVolume(r, h);

            
            Assert.AreEqual(expected, Math.Round(actual.Value, 4));
        }
        [TestMethod]
        public void CalcCylinderVolume_2and10_125Point664Returned()
        {
  
            double r = 2;
            double h = 10;
            double expected = 125.664;

    
            double? actual = CylinderCheker.CalculateVolume(r, h);

     
            Assert.AreEqual(expected, Math.Round(actual.Value, 3));
        }
        [TestMethod]
        public void CalcCylinderVolume_10and2_628Point319Returned()
        {

            double r = 10;
            double h = 2;
            double expected = 628.319;

            double? actual = CylinderCheker.CalculateVolume(r, h);

            Assert.AreEqual(expected, Math.Round(actual.Value, 3));
        }
        [TestMethod]
        public void CalcCylinderVolume_2andMinus2_NullReturned()
        {
     
            double r = 2;
            double h = -2;
            double? expected = null;

            double? actual = CylinderCheker.CalculateVolume(r, h);


            Assert.AreEqual(expected, actual);
        }
        [TestMethod]
        public void CalcCylinderVolume_Minus2and2_NullReturned()
        {

            double r = -2;
            double h = 2;
            double? expected = null;

 
            double? actual = CylinderCheker.CalculateVolume(r, h);

 
            Assert.AreEqual(expected, actual);
        }
    }
}
