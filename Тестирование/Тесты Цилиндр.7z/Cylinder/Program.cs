﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cylinder
{
    public class CylinderCheker
    {
        public static double? CalculateVolume(double radius, double height)
        {
            if (radius < 0 || height < 0)
            {
                Console.WriteLine("Высота или радиус цилиндра не могут быть отрицательными!");
                return null;
            }
            if (radius == 0 || height == 0)
            {
                Console.WriteLine("Значенимя не могут быть равными нулю или символьными!");
                return null;
            }
            return Math.PI * Math.Pow(radius, 2) * height;
        }


        static void Main()
        {
            double rad, h;
            Console.WriteLine("Введите радиус цилиндра");
            double.TryParse(Console.ReadLine(), out rad);
            Console.WriteLine("Введите высоту цилиндра");
            double.TryParse((string)Console.ReadLine(), out h);
            if (CalculateVolume(rad, h) != null)
                Console.WriteLine($"Объем цилиндра: {CalculateVolume(rad, h)}");
            return;
        }
    }
}